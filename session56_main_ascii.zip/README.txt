review_table_* = 적합성검토표_v201d_20261005_v1 (docx/pdf)
compare_v201d_v202.md = 대조표_v201d_v202
handover_56_20261005.md = 세션인수인계_56_20261005
phd_v202_20261005.docx = 논문 v202
